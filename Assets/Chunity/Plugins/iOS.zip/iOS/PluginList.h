DECLARE_EFFECT("ChucK", ChucK_For_Unity);
DECLARE_EFFECT("Stock Unity Spatializer", Spatializer);
DECLARE_EFFECT("Basic Panning Spatializer", Spatializer);
